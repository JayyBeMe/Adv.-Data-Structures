#include <iostream>
#include <ctime>
#include "Book.h"

/*
* Name: {Jeremiah Green}
* ULID: {C00306033}
* Course: CMPS 351-{002}
* Assignment: {PA 2 - Inventory Management}
* Certificate of Authenticity:
* I certify that the code in the method function main of this project
* is entirely my own work.
*/

using namespace std;


//Include driver code here in main to test all of your functions
int main() {
    //Since I'm so nice, here is an array of 30 different book objects that you can randomly
    //pull from to add to your inventory while testing your functions.


    Book books[] = {Book(1, "A Tale of Two Cities", "Charles Dickens", "Historical", 10.99, 3),
                      Book(2, "The Hobbit", "J. R. R. Tolkien", "Fantasy", 15.99, 2),
                      Book(3, "Harry Potter and the Philosopher's Stone", "J. K. Rowling", "Fantasy", 12.99, 1),
                      Book(4, "The Little Prince", "Antoine de Saint-Exupery", "Novella", 9.99, 3),
                      Book(5, "Dream of the Red Chamber", "Cao Xueqin", "Family saga", 8.99, 3),
                      Book(6, "And Then There Were None", "Agatha Christie", "Mystery", 8.50, 2),
                      Book(7, "The Lion, the Witch and the Wardrobe", "C. S. Lewis", "Fantasy", 11.80, 4),
                      Book(8, "She: A History of Adventure", "H. Rider Haggard", "Adventure", 6.99, 1),
                      Book(9, "To Kill a Mockingbird", "Harper Lee", "Southern Gothic Fiction", 12.99, 2),
                      Book(10, "The Da Vinci Code", "Dan Brown", "Mystery thriller", 17.50, 3),
                      Book(11, "Harry Potter and the Chamber of Secrets", "J. K. Rowling", "Fantasy", 12.99, 4),
                      Book(12, "Harry Potter and the Prisoner of Azkaban", "J. K. Rowling", "Fantasy", 12.99, 2),
                      Book(13, "Harry Potter and the Goblet of Fire", "J. K. Rowling", "Fantasy", 12.99, 2),
                      Book(14, "Harry Potter and the Order of the Phoenix", "J. K. Rowling", "Fantasy", 12.99, 1),
                      Book(15, "Harry Potter and the Half-Blood Prince", "J. K. Rowling", "Fantasy", 12.99, 3),
                      Book(16, "Harry Potter and the Deathly Hallows", "J. K. Rowling", "Fantasy", 12.99, 1),
                      Book(17, "The Alchemist (O Alquimista)", "Paulo Coelho", "Fantasy", 12.99, 3),
                      Book(18, "The Catcher in the Rye", "J. D. Salinger", "Coming-of-age", 13.50, 3),
                      Book(19, "Angels and Demons", "Dan Brown", "Mystery thriller", 17.50, 3),
                      Book(20, "The Diary of Anne Frank", "Anne Frank", "Historical", 14.50, 2),
                      Book(21, "How the Steel Was Tempered", "Nikolai Ostrovsky", "Socialist Realist", 13.50, 2),
                      Book(22, "War and Peace", "Leo Tolstoy", "Historical", 16.99, 4),
                      Book(23, "A People's History of the United States", "Howard Zinn", "Historical", 18.99, 5),
                      Book(24, "Guns, Germs, and Steel", "Jared Diamond", "Historical", 13.50, 2),
                      Book(25, "Nineteen Eighty-Four", "George Orwell", "Dystopian", 15.78, 1),
                      Book(26, "The Revolt of Mamie Stover", "William Bradford Huie", "Fiction", 20.00, 1),
                      Book(27, "The Girl with the Dragon Tattoo", "Stieg Larsson", "Fiction", 19.60, 1),
                      Book(28, "The Lost Symbol", "Dan Brown", "Fiction", 13.60, 3),
                      Book(29, "The Hunger Games", "Suzanne Collins", "Fiction", 14.50, 1),
                      Book(30, "The Grapes of wrath", "John Steinbeck", "American Realist", 15.00, 2)};


    // A sample for each loop in C++ should you need it in this project


    for(const Book& b : books) {
        cout << b.toString() << endl;
    }

    // Sample code to get a random book from the array i provided you with above.
    // remember to always seed your random generator with srand(time(0)) before using it
    srand(time(0));
    //note that you need the copy constructor to created properly before this will work
    Book b1 = books[(rand() % 30) + 1];



    return 0;
}
/*
 * • How many hours did you spend on this assignment?
 * About 17 hours
 *
 *• What was the most difficult part for you? Why?
 * debugging the errors to get a print statement. Its very hard for me to understand where
 * im going wrong when the code i implement has no errors but im not able to see the results of my prints.
 * Also knowing how to call what i print isnt the easiest
 *
 *• What was the easiest? Why?
 * Implementing the functions weren't horrible until I got to inventory class. It definitely wasn't easy, but I enjoyed
 * creating functions.
 */