//
// Created by Andrew on 2/3/2022.
// Header file for the Inventory class.
// Under no circumstances should this file be modified or changed in any way.
//

#ifndef PA2_CODEBASE_INVENTORY_H
#define PA2_CODEBASE_INVENTORY_H

#include "Book.h"

class Inventory {
public:
    /*
     * Standard Constructor for an Inventory Object
     * Sets the Book pointer to nullptr, both inventorySize and numBooks are set to zero
     */
    Inventory();
    /*
     * Standard destructor for the Inventory class. It should delete any and all dynamically allocated data
     * that the class instance is still holding. (Hint: Ensure all book pointers in the array have their
     * data deallocated, then deallocate the inventory array itself.)
     */
    ~Inventory();
    /*
     * This function adds a book to the store's inventory. It takes a Book as a parameter that is passed by value
     * and does not return a value. If there is another copy of the Book present in the inventory, the item
     * should be "stacked" in the same inventory slot by increasing the number of available copies in that slot.
     * If there is not another copy of the book present, it is placed in the next available inventory space at
     * the back of the inventory. If the book cannot be stacked and there are no available spaces, the size of the
     * dynamic inventory array should be increased by 4 spaces then the book should be added at the first open space
     * in the back.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     *      The book value parameter is not null and a proper object
     * Post-condition:
     *      The book has been added to the inventory
     */
    void addBook(Book);
    /*
     * This function attempts to reduce the number of available copies of a book from the store's inventory
     * by selling them. It takes a single Book parameter passed by reference and returns an integer. The
     * book parameter is a standard book with a small exception, it's numberAvailable value represents the
     * desired number wishing to be sold. The integer returned by the function represents the number of items
     * that could not be sold from the inventory. For example: say the user wishes to sell 10 copies of a book.
     * The book parameter's numberAvailable will equal 10. Now assume the inventory only contain 6 copies of the
     * book. In this case, the 6 present copies should be sold, reducing the number of available copies in the
     * inventory to 0, and 4 is returned to the user so they know 4 copies could not be sold. this function does not
     * change the number of inventory spaces used.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     *      The book reference parameter is not null and a proper object
     * Postcondition:
     *      Then the highest possible number of copies has been sold. The number of unsold copies has been
     *      returned.
     */
    int sellBook(Book&);
    /*
     * This function attempts to completely remove a book from the store's inventory system. It takes a single
     * formal book parameter passed as a pointer and returns a boolean value. When a book is removed,
     * all items in the inventory after the removed book should be shifted up a space. In this manner,
     * the dynamic inventory array should never have an empty slot surrounded by filled spaces. All empty
     * spaces are located at the "back" (highest indexes) of the array. After removal, if the inventory
     * contains more than 2 open spaces, the size of the inventory array should be reduced by two. This size
     * reduction should not change anything else about the inventory.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     *      A book pointer is passed to the function
     * Postcondition:
     *      If found, the book has been completely removed from the inventory, space has been consolidated,
     *      and true is returned. Otherwise, false is returned.
     */
    bool removeFromInventory(Book*);
    /*
     * This function checks if a book is in stock. It takes a single formal Book pointer parameter and returns
     * a boolean value. The function returns true if there is at least one copy of the book present in the
     * inventory. Otherwise, false is returned. As always, Books are matched on their ID.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     *      A book pointer is passed to the function
     * Postcondition:
     *      If a single copy of the book is present in the inventory, true is returned.
     *      Otherwise, false is returned.
     */
    bool inStock(Book*);
    /*
     * This function simply determines the total cost of all books in the inventory and returns it to the
     * user. It does not take any parameters and returns a double
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     * Postcondition:
     *      The total value of all books in the inventory has been returned to the user.
     */
    double calculateInventoryCost();
    /*
     * This function simply determines the total number of all books in the inventory and returns it to the
     * user. It does not take any parameters and returns an integer.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     * Postcondition:
     *      The total number of books in the inventory has been returned to the user.
     */
    int totalBookCount();
    /*
     * This function prints the contents of the inventory to the screen.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     * Post-condition:
     *      A nice header is printed followed by printing the result of the toString function for all
     *      books in the inventory to the screen. Empty spaces should be printed and simply shown as "empty"
     */
    void printInventory();
    /*
     * This function prints all the books in the inventory by a specific author to the screen.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     * Postcondition:
     *      A nice header is printed followed by printing the result of the toString function for all
     *      matching books in the inventory to the screen.
     */
    void printAllByAuthor(const string);
    /*
     * This function prints all the books in the inventory that are a specific genre to the screen.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     * Postcondition:
     *      A nice header is printed followed by printing the result of the toString function for all
     *      matching books in the inventory to the screen.
     */
    void printAllByGenre(const string);
    /*
     * Optional bonus function worth 15 bonus points. Partial credit will not be given.
     * When called, this function sorts the items in the inventory into ascending order using your favorite
     * sorting function. You may add helper functions to Inventory.cpp to assist your implementation if
     * needed. Helper functions must be declared at the very top of the file, and implemented at the very
     * bottom of the file. Not meeting this setup requirements will void you of any bonus points.
     */
    void sort();
private:
    /*
     * Pointer to the dynamic array that will hold pointers to book objects to represent the inventory.
     * Since the Book items are created dynamically, this needs to be a double pointer, making the array
     * hold pointers to pointers. *insert spider-man meme here*
     */
    Book** inventory;
    /*
     * Integer representing the number of available spaces in the dynamic array representing the inventory.
     * Should always equal the size of the dynamic array
     */
    int inventorySize;
    /*
     * Integer representing the number of unique books in the inventory. Should always equal the number of
     * array slots that are filled.
     */
    int numBooks;
    /*
     * This function changes the size of the dynamic array that represents the inventory. It takes a single
     * boolean formal parameter and does not return a value. If the parameter's value is true, the size of the
     * array is increased as described in the description of the addBook function, otherwise its size is
     * decreased as described by the removeFromInventory function above.
     * Precondition:
     *      The inventory instance object has been properly created and initialized
     *      The book value parameter is not null and a proper object
     * Postcondition:
     *      The book has been added to the inventory
     */
    void changeInventorySize(bool);
};

#endif //PA2_CODEBASE_INVENTORY_H