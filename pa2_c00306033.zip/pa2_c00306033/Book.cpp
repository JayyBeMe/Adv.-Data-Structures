//
// Finish the implementation the functions in the Book class here
// according to their description in the header file (Book.h)
// I have done three functions to get you started. The rest is up
// to you.
//

#include "Book.h"
/*
    * The book function takes six parameters that declares different features of a book including its features,price, amd
    * availability
    * Precondition:
    *     The book instance is initialized
    * Postcondition:
    *   All parameters passed through function are declared using new variables
    *
    */
Book::Book(int ID, string name, string author, string genre, double price, int numberAvailable) {
    this->ID = ID;
    this->name = name;
    this->author = author;
    this->genre = genre;
    this->price = price;
    this->numberAvailable = numberAvailable;
}

    /*
    * The inStock function tells the user if a book is in stock by returning a boolean true or false
    * Precondition:
    *   The Book instance is initialized
    *
    * Postcondition:
    *   Function returns true if the book is in stock and false if it isnt.
    */
bool Book::inStock() const {
    if(this->numberAvailable > 0){
        return true;
    }
    else
        return false;
}

    /*
    * The function makes a copy of the Book passed through the parameter
    * Precondition:
    *   The Book instance is initialized
    *
    * Postcondition:
    *   A copy of the passed book is returned
    */
Book::Book(const Book& toCopy){return;}

    /*
    * This function gets the ID from its associated Book
    * Precondition:
    *   The Book instance is initialized
    *
    * Postcondition:
    *   The ID is returned
    */
int Book::getID() const {
    return this->ID;
}


    /*
   * This function gets the name from its associated Book
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The name is returned
   */
string Book::getName() const {
    return this->name;
}
/*
   * This function gets the author from its associated Book
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The author is returned
   */
string Book::getAuthor() const {
    return this->author;
}

/*
   * This function gets the genre its associated Book
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The genre is returned
   */
string Book::getGenre() const {
    return this->genre;
}
/*
   * This function gets the price from its associated Book
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The price is returned
   */
double Book::getPrice() const {
    return this->price;
}
/*
   * This function gets the number available from its associated Book
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The number available is returned
   */
int Book::getNumberAvailable() const {
    return this->numberAvailable;
}
/*
   * This function has a parameter amount that takes an int of books to
   * add to the numberAvailable
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The amount requested is added to the number available and returned
   */
void Book::addStock(int amount) {

    numberAvailable = numberAvailable + amount;
    return;
}

/*
   * This function removes a desired number of books from the stock depending on what is passed through the amount
   * parameter.
   * Precondition:
   *   The Book instance is initialized
   *
   * Postcondition:
   *   The amount requested is removed and the new numberAvailable is returned
   */
void Book::removeStock(int amount) {
    if (numberAvailable <= 0){
        numberAvailable = 0;
        return;

    }
    else{
        numberAvailable = numberAvailable - amount;
        return;


    }
}



//Bonus Section Undone







/*
 * To ensure consistent readability in the output,
 * I have done this function for you.
 * Use this sample to create the headers with the
 * same spacing for your output in the print functions
 * of the inventory class.
 *   - Prof. Andrew :)
 */
string Book::toString() const {
    char buffer[150];
    sprintf(buffer, "%-5d \t%-30.30s \t%-20.20s \t%-20.20s \t%-6.2f \t%-3d", ID, name.c_str(), author.c_str(), genre.c_str(), price, numberAvailable);
    return buffer;
}