//
// Created by Andrew on 2/2/2022.
// Header file for the Book class.
// Under no circumstances should this file be modified or changed in any way.
// If this is implemented incorrectly, your Inventory class will not work properly
//

#ifndef PA2_CODEBASE_BOOK_H
#define PA2_CODEBASE_BOOK_H

#include <string>
using namespace std;

class Book {
public:
    /*
     * Standard default constructor that takes a value for all data variables
     * and returns a newly created book instance object with the provided data
     */
    Book(int, string, string, string, double, int);
    /*
     * Standard copy constructor that takes another Book instance object as a
     * formal parameter passed by reference and returns a new book object that is an exact copy
     */
    Book(const Book& toCopy);
    //Standard getter functions for private data
    /*
     * This function gets the id number of the book as an integer
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The id number of the book is returned as an integer
     */
    int getID() const;
    /*
     * This function gets the name of the book as a string
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The name of the book is returned as a string
     */
    string getName() const;
    /*
     * This function gets the name of person who authored the book as a string
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The name of the book's author is returned as a string
     */
    string getAuthor() const;
    /*
     * This function gets the genre of the book as a string
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The genre of the book is returned as a string
     */
    string getGenre() const;
    /*
     * This function gets the price for the book as a double
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The price for the book is returned as a double
     */
    double getPrice() const;
    /*
     * This function gets the number of books available as an integer
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      The number of the book available has been returned as an integer
     */
    int getNumberAvailable() const;
    /*
     * This function returns if a book instance object is available in stock or not
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      if numberAvailable is > 0: true is returned, otherwise false is returned
     */
     bool inStock() const;
    /*
     * This function adds a specific number of books to be available
     * Precondition:
     *      A book instance object has been properly created and initialized
     *      0 < amount < INT_MAX
     * Postcondition:
     *      numberAvailable has been increased by the desired amount
     */
    void addStock(int amount);
    /*
     * This function removes a specific number of books from being available
     * Precondition:
     *      A book instance object has been properly created and initialized
     *      0 <= amount < INT_MAX
     * Postcondition:
     *      numberAvailable has been decreased by the desired amount.
     *      numberAvailable has not been reduced below 0
     */
    void removeStock(int amount);
    /*
     * This function creates and returns a string representation of the book instance object
     * Precondition:
     *      A book instance object has been properly created and initialized
     * Postcondition:
     *      A string containing the book's ID, name, author, genre, price, and availability
     *      (in that order) has been returned to the user.
     */
    string toString() const;
    /*
     * Optional bonus function worth 3 points. Partial credit will not be given
     * The function takes a formal book parameter passed by reference and
     * compares it to this Book object it for equality
     * Precondition:
     *      This book instance object has been properly created and initialized
     *      The book reference parameter has been properly created and initialized
     * Postcondition:
     *      The function returns true if the books are equal (their ID's are the same),
     *      otherwise false is returned
     */
    bool operator==(const Book&) const;
    /*
     * Optional bonus function worth 3 points. Partial credit will not be given
     * The function takes a formal book parameter passed by reference and
     * compares it to this Book object
     * Precondition:
     *      This book instance object has been properly created and initialized
     *      The book reference parameter has been properly created and initialized
     * Postcondition:
     *      The function returns true if this book is less than the book passed in
     *      (this ID is less than the passed book's ID), otherwise false is returned
     */
    bool operator<(const Book&) const;
    /*
     * Optional bonus function worth 3 points. Partial credit will not be given
     * The function takes a formal book parameter passed by reference and
     * compares it to this Book object
     * Precondition:
     *      This book instance object has been properly created and initialized
     *      The book reference parameter has been properly created and initialized
     * Postcondition:
     *      The function returns true if this book is greater than the book passed in
     *      (this ID is greater than the passed book's ID), otherwise false is returned
     */
    bool operator>(const Book&) const;
private:
    //integer representing the ID for the book
    int ID;
    //string representing the name of the book
    string name;
    //string representing the name of the book's author
    string author;
    //string representing the genre of the book
    string genre;
    //double representing the price of the book
    double price;
    //integer representing the current number of available copies for the book
    int numberAvailable;
};


#endif //PA2_CODEBASE_BOOK_H
