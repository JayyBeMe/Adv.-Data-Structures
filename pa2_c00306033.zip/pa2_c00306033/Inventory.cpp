//
// Finish the implementation the functions in the Inventory class here
// according to their description in the header file (Inventory.h)
// This implementation is entirely up to you.
//
#include <iostream>
#include "Inventory.h"
#include "Book.h"



/*
 * To ensure consistent output, use this code for the header in your print functions:
 * 
 * 	char header[150];
 * 	sprintf(header, "%-5.5s \t%-30.30s \t%-20.20s \t%-20.20s \t%-6.6s \t%-10.10s", "ID", "Title", "Author", "Genre", "Price", "Num Avail.");
 *
 *  std::cout << "Slot\t" << header << endl;
 */
using namespace std;

/*
   * The standard constructor is created to set inventory to nulllptr which is essentially leaving it blank as well as
   * setting inventorySize and numBooks to zero
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *  Inventory set to nullptr, inventorySize and numBooks set to zero
   */
Inventory::Inventory() {
    inventory = nullptr;
    inventorySize = 0;
    numBooks = 0;

}
//deletes any and all dynamically allocated data
/*
   * The deconstuctor deletes any and all dynamically allocated data
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Inventory data is deleted.
   */
Inventory::~Inventory() {
    for(int i = 0; i < inventorySize; i++){
        delete inventory[i];
    }
    delete[] inventory;

}

/*
   * The addBook function adds a book into the inventory and stacks it if the same book already exists in the inventory
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *    Book is added and the number of books is increased
   */
void Inventory::addBook(Book find) {

    for(int i  = 0; i < numBooks; i++ ){
        if( inventory[i]->getID() == find.getID()){
            inventory[i]->addStock(find.getNumberAvailable());
            return;
        }
    }
    if (inventorySize == numBooks){
        changeInventorySize(true);
    }
    inventory[numBooks++] = new Book(find);





}

/*
   * The sell book function passes a Book parameter address to have that book sold from the inventory, decreasing
   * inventory size
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   The book is sold
   */
int Inventory::sellBook(Book & find) {
    int Book;
    for(int i  = 0; i < numBooks; i++ ){
        if( inventory[i]->getID() == find.getID()){
            int inventorySize = inventorySize - Book;
            int numberAvailable = numberAvailable - Book;
            if (numberAvailable < 0)return -(numberAvailable);
            else return numberAvailable;

        }
        else
            int inventorySize = inventorySize - Book;
            int numberAvailable = numberAvailable - Book;
    }
}

/*
   * The function removes a book passed as a point parameter from the inventory
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Boolean function returns true if the book is found and removed or false if not
   */
bool Inventory::removeFromInventory(Book * find) {
    bool remove = false;
    int before = numBooks;

    for(int i  = 0; i < numBooks; i++){
        if( inventory[i]->getID() == find->getID()){
            remove = true;
            delete inventory[i];
            return true;
        }
        else
            return false;

    }
}

/*
   * The function is a passed a pointer parameter and looks to see if a book is in stock or not
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   If the book is in stock and the ID matches in the code boolean true is returned, else false is returned
   */
bool Inventory::inStock(Book * find) {
    for (int i = 0; i < numBooks; i++) {
        if (inventory[i]->getID() == find->getID()) {
            return true;
        }
        else
            return false;
    }
}

/*
   * The function calculates the total cost of all Books being held in the inventory
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
   *    The total is returned
    *
   */
double Inventory::calculateInventoryCost() {
    for (int i = 0; i < numBooks; i++) {
        double Price = inventory[i]->getPrice();
        double total = total + Price;
        return total;

    }
}

/*
   * The function counts the total number of books kept in the inventory
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
   *    Total number of books in inventory is returned
    *
   */
int Inventory::totalBookCount() {
    for (int i = 0; i < numBooks; i++) {
        numBooks = inventory[i]->getNumberAvailable();
        int totalnumBooks = totalnumBooks + numBooks;
        return totalnumBooks;
    }

}

/*
   * The function prints the inventory
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Inventory is printed
   */
void Inventory::printInventory(){

    char header[150];
    sprintf(header, "%-5.5s \t%-30.30s \t%-20.20s \t%-20.20s \t%-6.6s \t%-10.10s", "ID", "Title", "Author", "Genre", "Price", "Num Avail.");
    std::cout << "Slot\t" << header << endl;
    std::cout << inventory << std::endl;
}

/*
   * The function prints the authors
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Authors are printed
   */
void Inventory::printAllByAuthor(const string) {

    char header[150];
    sprintf(header, "%-5.5s \t%-30.30s \t%-20.20s \t%-20.20s \t%-6.6s \t%-10.10s", "ID", "Title", "Author", "Genre", "Price", "Num Avail.");
    std::cout << "Slot\t" << header << endl;
    //std::cout << inventory << std::endl;


}
/*
   * The function prints the genres
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Genres are printed
   */
void Inventory::printAllByGenre(const string) {

    char header[150];
    sprintf(header, "%-5.5s \t%-30.30s \t%-20.20s \t%-20.20s \t%-6.6s \t%-10.10s", "ID", "Title", "Author", "Genre", "Price", "Num Avail.");
    std::cout << "Slot\t" << header << endl;

}
/*
   * The function changes the size of the inventory
   *
   * Precondition:
   *   The Inventory instance is initialized
   *
   * Postcondition:
    *   Inventory is increased by 4 if true and decreased by 2 if false
   */
void Inventory::changeInventorySize(bool change) {
    if(change == true){
        inventorySize += 4;

    }
    if (change == false){
        inventorySize -= 2;

    }
}

